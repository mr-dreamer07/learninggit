package com.example.automatedtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomatedtrackerApplicationTests {

    @Test
    void contextLoads() {
    }

}
