package com.example.automatedtracker;

import org.springframework.stereotype.Component;


public class FileInfo {

    private long id;
    private String path;

    public FileInfo(long id, String path){
        this.id = id;
        this.path = path;

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    @Override
    public String toString() {
        return "FileInfo{" +
                "id=" + id +
                ", path='" + path + '\'' +
                '}';
    }
}
