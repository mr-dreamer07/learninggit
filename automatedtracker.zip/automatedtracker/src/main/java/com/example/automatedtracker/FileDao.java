package com.example.automatedtracker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class FileDao {

    long currId;
    @Autowired
    JdbcTemplate jdbcTemplate;

    public void getFileFromDatabase(){

      List<Object> id = jdbcTemplate.query("select id from fileTable where id = last_inserted_id",
                   new BeanPropertyRowMapper(FileInfo.class));

       long lastId = -1;
       if(id.size() > 0)
        lastId = (int)id.get(0);

       if(lastId > currId){
           currId++;
           List<FileInfo> filedata = jdbcTemplate.query("select * from fileTable where id = currId",
                   new BeanPropertyRowMapper(FileInfo.class));

           System.out.println(filedata.get(0).getId() + "  " + filedata.get(0).getPath());

       }

    }

}
